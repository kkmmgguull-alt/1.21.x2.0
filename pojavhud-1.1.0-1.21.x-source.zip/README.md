# PojavHUD 1.1.0 – Minecraft 1.21.x

Customizable item texture overlay for hotbar slots 1–9.
Designed for PojavLauncher touchscreen buttons.

## Features
- Shows items from hotbar slots 1–9 automatically
- Fully movable / resizable / opacity adjustable
- Press **O** to open editor
- Press **N** to toggle visibility
- Mod Menu support + icon
- Works on Minecraft **1.21.x** (1.21.1 → 1.21.11)

## Build
```bash
./gradlew build
```
Jar will be in `build/libs/pojavhud-1.1.0.jar`
